# RetroPie Web

A small self-hosted website that turns any phone/tablet/laptop connected to
your Pi's **RetroPie** hotspot into either:

- **Screen** — a live mirror of what's on the RetroPie display
- **Controller** — a touch gamepad (11 console layouts) that acts as a real
  USB-style controller
- **Both** — screen and controller together on one page

Plus a **Settings** page to tune capture quality, resolution, controller
layout, and player count — no editing files by hand.

---

## How it works

| Piece | What it does |
|---|---|
| `server/index.js` | Node/Express server. Serves the site, exposes `/stream` (MJPEG) and `/controller-ws` (WebSocket), and a small settings API. |
| `server/capture.js` | Spawns `ffmpeg` to grab the Pi's screen (KMS/DRM, framebuffer, or X11) and re-encodes it as MJPEG — no extra players/plugins needed in the browser, and no STUN/TURN server required, which matters because the hotspot has no internet. |
| `server/uinput_gamepad.py` | Creates real virtual gamepad(s) via Linux's `uinput` — 15 buttons, 2 d-pad-style hats, 2 analog sticks per pad. RetroArch/EmulationStation see them exactly like a USB controller. |
| `public/` | The front-end: boot-menu style home screen, screen view, multi-console touch controller with drag-to-reposition, combined view, settings. Plain HTML/CSS/JS, no build step, no CDN dependencies (works fully offline on the hotspot). |

**Why MJPEG instead of WebRTC?** WebRTC gives lower latency but normally
needs a signaling/STUN server to negotiate connections. On an isolated
hotspot with no internet, that adds real complexity for not much benefit at
retro-game framerates. MJPEG works instantly with zero extra infrastructure.

---

## Install on the Pi

Copy this whole folder to the Pi (e.g. via `scp` or a USB stick), then:

```bash
cd retropie-web
sudo bash install.sh
```

This one script does **everything**, start to finish, and is **safe to
re-run** any time you get a new version of this app:

1. Installs `ffmpeg`, Node.js 20, and `python3-uinput`.
2. Sets up `uinput` group + udev rule, and `video`/`render` group + DRM
   device permissions (needed for KMS/DRM screen capture).
3. **Rebuilds the `RetroPie` / `retrogames` Wi-Fi hotspot from scratch** —
   tears down any existing AP-mode connection (any SSID, any tool: old
   NetworkManager hotspot profiles, `hostapd`/`dnsmasq` configs) and builds
   a fresh one, via NetworkManager (the default on current Raspberry Pi
   OS/Trixie) or `hostapd`+`dnsmasq` as a fallback. This only touches
   AP-mode profiles — a normal client Wi-Fi connection on this Pi (e.g. for
   internet access) is left alone.
4. Copies the app to `/opt/retropie-web`, fresh each time.
5. Grants Node permission to bind to port 80, and grants `ffmpeg`
   `CAP_SYS_ADMIN` (needed specifically for KMS/DRM capture).
6. Installs and starts a `systemd` service (`retropie-web`) so it comes up
   automatically on boot.

**Reboot once after install** so new group memberships (`uinput`, `video`,
`render`) take effect.

Then, on the phone/tablet/laptop: connect to Wi-Fi `RetroPie` (password
`retrogames`) and open `http://<pi-ip>/` (find the IP with `hostname -I` on
the Pi). Consider setting a static IP for the hotspot interface so the URL
never changes.

### Updating later: quick update vs. full reinstall

Most changes (UI tweaks, new controller layouts, bug fixes) only touch the
`server/` and `public/` folders — for those, a **quick update** is enough
and doesn't disturb your hotspot or reset anything:

```bash
# on the Pi
sudo systemctl stop retropie-web
sudo cp -r /path/to/new/server /path/to/new/public /opt/retropie-web/
sudo chown -R pi:pi /opt/retropie-web
sudo systemctl restart retropie-web
```

Only re-run `sudo bash install.sh` (the **full reinstall**) when told
specifically that the installer itself changed — new system packages,
permissions, or hotspot logic. It rebuilds the hotspot (briefly
disconnects everyone) and resets Settings to defaults.

---

## Screen capture: KMS/DRM vs X11 vs framebuffer

RetroPie setups vary in how they draw to the screen. The Settings page
lets you flip between three `ffmpeg` capture methods without touching
config files:

- **KMS/DRM (`kmsgrab`)** — the default, and correct for most current
  RetroPie setups on a Pi 4, where EmulationStation/RetroArch render
  straight to the display via the GPU/DRM, with no X server and without
  going through the legacy fbdev console layer either. Reads directly from
  the DRM plane actually being scanned out to the TV, so it sees whatever
  is really on screen regardless of what's drawing it.
- **X11 (`x11grab`)** — only relevant if RetroPie runs under a full X11
  desktop session (`DISPLAY=:0`).
- **Framebuffer (`fbdev`)** — legacy `/dev/fb0`. On modern Pi setups this
  is usually just the plain text console, frozen at whatever was on it
  before RetroArch took over the display via KMS — so this method
  typically shows the terminal, not the game. Rarely the right choice
  anymore, kept for older/unusual setups.

### Setting up KMS/DRM capture on your specific Pi

Two settings vary per device and must be found by testing directly on the
Pi (from an SSH session or the console, **not** from this app, since a
wrong guess just shows "no signal" rather than anything useful):

**1. Find the right DRM device.** Pi 4s commonly expose two:
`/dev/dri/card0` and `/dev/dri/card1`. One is often a render-only node
that doesn't support the planes API at all; the other is the real display
device. Test each:
```bash
ls /dev/dri
sudo ffmpeg -f kmsgrab -device /dev/dri/card0 -i - -vf 'hwdownload,format=bgra' -frames:v 1 /tmp/test.png
sudo ffmpeg -f kmsgrab -device /dev/dri/card1 -i - -vf 'hwdownload,format=bgra' -frames:v 1 /tmp/test.png
```
Whichever one succeeds and logs something like `Using plane N to locate
framebuffers` (rather than `Failed to set universal planes capability`) is
the right device. Pull the resulting `/tmp/test.png` off the Pi and
confirm it actually shows EmulationStation/the game, not a blank or
garbled image.

**2. Match the pixel format.** The same `ffmpeg` output above prints the
source format as an 8-hex-digit DRM fourcc code, e.g. `format 34325241`.
Decode it by reading the hex as 4 ASCII bytes in reverse byte order — or
just match against this table of the common ones:

| ffmpeg reports (fourcc) | Meaning | Use `kmsPixelFormat` |
|---|---|---|
| `34325241` (`AR24`) | ARGB8888 (has alpha) | `bgra` |
| `34325258` (`XR24`) | XRGB8888 (no alpha) | `bgr0` |
| `34324241` (`AB24`) | ABGR8888 | `rgba` |
| `34324258` (`XB24`) | XBGR8888 | `rgb0` |

If `hwdownload` errors with `Invalid output format <x> for hwframe
download`, the format doesn't match — try the next candidate from the
table, or rerun the one-frame test above swapping `format=bgra` for the
other options until you get a real image.

Once you know both values, set them in **Settings → Screen Capture → DRM
device / DRM pixel format** (defaults in this repo are `/dev/dri/card1` /
`bgra`, which is what the original dev Pi needed — yours may differ).

If the Screen view shows **"No signal after 6s"**, that's always this —
go find the right device/format with the manual test above rather than
guessing in the UI.

---

## Controller: choosing a layout, repositioning buttons, and RetroArch setup

### Choosing a layout

The **Controller** and **Screen + Controller** views have a layout picker
right at the top — pick the console you're playing and the on-screen
buttons update immediately. It remembers your last choice on that device.
Available layouts:

NES · SNES · Game Boy · Game Boy Color · Game Boy Advance · Nintendo 64 ·
GameCube · Wii · PlayStation 4 · Mega Drive/Genesis · MAME/Arcade

Each shows the buttons that console actually has — e.g. N64 gets an analog
stick plus a separate C-button cluster, Genesis/MAME get a real 6-button
grid, PS4 gets both analog sticks, △○✕□, and all four shoulder/trigger
buttons.

Every layout is really just a different arrangement of the same fixed set
of physical buttons/axes the virtual controller always exposes (see
`server/uinput_gamepad.py`): 15 buttons, 2 hats, 2 analog sticks. Want to
adjust a layout, or add another console? Everything lives in the
`LAYOUTS` object at the top of `public/controller.js` — each entry just
lists which elements it has; the renderer builds the on-screen buttons
automatically.

### Repositioning buttons (per-console, per-device)

Tap **EDIT LAYOUT** on the Controller screen to drag any button, stick,
d-pad, or button cluster to wherever fits your hand best. Positions save
automatically per console layout (your N64 stick position and PS4 stick
position can be different) and per browser/device (stored in that
browser's `localStorage` — no account, nothing sent to the server). Tap
**RESET** while in edit mode to snap that console's layout back to
default.

### One-time setup in RetroArch

The virtual gamepads show up in Linux/RetroArch as **"RetroPieWeb Pad
1"**, **"...Pad 2"**, etc. — real input devices as far as RetroArch is
concerned. The first time you use a given player slot, open RetroArch's
**Settings → Input → Port 1 Controls → Set All Controls** and press each
prompted button. Because every on-screen layout maps onto the same
underlying physical buttons, **this is a one-time step per player slot** —
switching which console layout you're using afterwards doesn't require
re-binding.

**If RetroArch says the controller isn't connected**, even though the
app's own status bar says `PAD: READY`, check these in order:

1. **Confirm the OS actually sees it:**
   ```bash
   cat /proc/bus/input/devices | grep -A5 RetroPieWeb
   ```
   Should show `RetroPieWeb Pad 1`/`2` with real `event`/`js` handlers. If
   this is empty, the problem is the daemon/permissions, not RetroArch —
   check `sudo journalctl -u retropie-web -f` and `groups pi` /
   `ls -la /dev/uinput` (should show group `input` or `uinput`, and your
   user should be in one of those groups).

2. **Check the joypad driver** (this is the one that matters for
   hotplugged/virtual controllers — not `input_driver`, which only covers
   keyboard/mouse):
   ```bash
   grep joypad_driver /opt/retropie/configs/all/retroarch.cfg
   ```
   or check **RetroArch Quick Menu → Settings → Drivers → Joypad Driver**
   directly (more reliable than the config file if that line is commented
   out). It should be `udev`. A driver without hotplug support can miss a
   device created *after* RetroArch already started — if so, this is a
   **boot-order race**: if EmulationStation/RetroArch autostart before our
   `retropie-web` service finishes creating the virtual pad, RetroArch
   never sees it, even though the OS does. Test by restarting the service
   and then fully exiting RetroArch back to EmulationStation and
   relaunching the game (not just pressing a button — the joypad list is
   typically rescanned at RetroArch startup):
   ```bash
   sudo systemctl restart retropie-web
   ```

3. **Stale autoconfig profile** — if you ever bound controls while an
   older/differently-named version of this app's virtual pad was running,
   RetroArch may have saved a profile tied to the old exact device name
   that no longer matches. Check and remove:
   ```bash
   grep -rl "RetroPie" /opt/retropie/configs/all/retroarch/autoconfig/ 2>/dev/null
   grep -rl "RetroPie" ~/.config/retroarch/autoconfig/ 2>/dev/null
   ```
   If either finds a file, delete it and redo "Set All Controls".

---

## The Wi-Fi hotspot

Set up by `install.sh` using NetworkManager (`nmcli`) by default. A few
things worth knowing if you ever need to debug it by hand:

- **List what NetworkManager knows about:** `nmcli device status` and
  `nmcli connection show`. The hotspot profile is named `RetroPie` and
  should show `802-11-wireless.mode: ap`.
- **Only one Wi-Fi profile can own the radio at a time.** If this Pi also
  has a normal client profile (e.g. connecting to your home network for
  internet access), make sure it has `connection.autoconnect no` —
  otherwise it can win the "which profile gets `wlan0`" race on boot and
  silently replace your hotspot. Check: `nmcli -g connection.autoconnect
  connection show <name>`. Fix:
  `sudo nmcli connection modify <name> connection.autoconnect no`.
- **Manually toggle between the hotspot and a client network** (e.g. to
  let the Pi itself reach the internet temporarily for `apt`/`pip`):
  ```bash
  sudo nmcli connection down RetroPie
  sudo nmcli connection up <your-home-wifi-profile-name>
  # ...download whatever you needed...
  sudo nmcli connection down <your-home-wifi-profile-name>
  sudo nmcli connection up RetroPie
  ```
  This only matters for the Pi's own internet access — a phone/laptop that
  wants internet while also using this app can just switch *that device's*
  Wi-Fi network instead; the Pi's hotspot keeps running throughout.
- **Duplicate/leftover profiles** can pile up if `install.sh` (pre-this
  version) was run multiple times. Clean up with
  `sudo nmcli connection delete <name>` for anything stale — keep the one
  named `RetroPie` in `ap` mode.

---

## SSH access (including from a phone/tablet)

SSH is already enabled if you've been running these commands directly on
the Pi. To connect from an iPad/iPhone, a good free option is **Secure
ShellFish** (also integrates with the Files app for browsing/editing files
on the Pi); **Blink Shell** is a solid paid alternative. Connect to the
`RetroPie` Wi-Fi network first, then add a host: IP `10.42.0.1` (the
default NetworkManager hotspot gateway address — confirm yours with
`hostname -I` on the Pi if you used the `hostapd` fallback, which defaults
to `192.168.50.1` instead), port `22`, username `pi`.

---

## Troubleshooting a crashing/rebooting Pi

If the Pi kernel-panics or reboots under load (look for something like
`Kernel panic - not syncing: Asynchronous SError Interrupt` in
`dmesg`/console output), that's almost always a **hardware/power issue**,
not an app bug — screen capture + hotspot + emulation together is more
sustained load than stock RetroPie. Check:
```bash
vcgencmd get_throttled    # anything other than 0x0 = undervoltage/throttling occurred
vcgencmd measure_temp     # sustained >80°C will throttle
journalctl -b -1 -p err --no-pager | tail -100   # errors from the crashed boot
```
Use the official 5V/3A USB-C supply (phone chargers and cheap cables are
the most common cause of exactly this kind of instability), and check
whether crashes correlate with having the **Screen** view open (capture
only runs while someone's actually watching, so if panics cluster around
those times, that's a strong signal it's capture-pipeline-related rather
than unrelated SD card/RAM issues).

---

## Security note

This is designed for a closed local hotspot with people you trust (that's
the whole point of the RetroPie network). There's no login. If you ever
bridge this hotspot to the internet or a shared network, put it behind a
reverse proxy with authentication first — anyone who can reach the server
can currently press buttons on your controller.

---

## Customizing the look

Everything visual lives in `public/style.css` at the top, in a block of
CSS variables (`:root { --bg: ...; --phosphor: ...; }`). Change those and
the whole theme follows. Fonts are system stacks on purpose (the hotspot
has no internet, so no font CDN) — if you want a specific pixel font, drop
the `.woff2` file in `public/fonts/` and add an `@font-face` rule.

---

## Troubleshooting quick index

- **"PAD: OFFLINE" in the status bar** — `uinput` daemon isn't running /
  can't access `/dev/uinput`. `sudo journalctl -u retropie-web -f`, and
  make sure you rebooted after `install.sh` (group membership needs a
  fresh login).
- **"SCREEN: IDLE" / black screen with no message** — this was a real bug
  in early versions (a CSS rule hid the "Connecting…" text based on
  `img[src]` presence rather than an actual loaded frame) — fixed by
  driving all placeholder visibility from JS with an explicit stall
  timeout (`public/screen.js`). If you see a blank black box with no text
  at all even on the current version, you're running stale front-end
  files — redeploy `public/`.
- **"No signal" on Screen** — see the whole KMS/DRM section above; 95% of
  the time it's the wrong `kmsDevice` or `kmsPixelFormat`.
- **Controller shows READY in this app, but RetroArch says not
  connected** — see the "One-time setup in RetroArch" troubleshooting
  steps above (joypad driver, boot-order race, stale autoconfig).
- **Hotspot not showing up, or disconnects after a while** — see "The
  Wi-Fi hotspot" section above (usually a competing autoconnect profile).
- **Pi crashes/reboots under load** — see "Troubleshooting a
  crashing/rebooting Pi" above (check power supply first).
