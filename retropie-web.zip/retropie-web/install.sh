#!/usr/bin/env bash
# Install script for RetroPie Web on Raspberry Pi OS / Debian Trixie.
# Run this ON THE PI itself: sudo bash install.sh
#
# This does a FULL rebuild every time it's run: it tears down any existing
# Wi-Fi access point (any SSID, any tool) and any previous install of this
# app, then builds everything fresh. Safe to re-run, but note it WILL
# briefly disconnect anyone on the hotspot and reset Settings to defaults.
set -euo pipefail

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root: sudo bash install.sh"
  exit 1
fi

INSTALL_DIR="/opt/retropie-web"
RUN_USER="${SUDO_USER:-pi}"
# Capture the directory this script lives in BEFORE any `cd` below changes
# the shell's working directory - otherwise a later relative path lookup
# (for retropie-web.service) resolves against the wrong place.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Installing system packages (ffmpeg, Node.js, Python uinput deps)..."
apt-get update
apt-get install -y ffmpeg python3 python3-pip python3-dev build-essential curl iw

if ! command -v node >/dev/null 2>&1; then
  echo "==> Installing Node.js 20.x..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

echo "==> Installing python-uinput..."
pip3 install --break-system-packages python-uinput

echo "==> Setting up /dev/uinput access..."
if ! getent group uinput >/dev/null; then
  groupadd uinput
fi
usermod -aG uinput "$RUN_USER"
cat > /etc/udev/rules.d/60-retropie-web-uinput.rules <<'EOF'
KERNEL=="uinput", GROUP="uinput", MODE="0660"
EOF
udevadm control --reload-rules
udevadm trigger
if ! grep -q '^uinput$' /etc/modules 2>/dev/null; then
  echo "uinput" >> /etc/modules
fi
modprobe uinput || true

echo "==> Setting up screen capture permissions (KMS/DRM + framebuffer)..."
# kmsgrab needs to read the DRM device directly; fbdev capture needs the
# 'video' group. Add both so whichever capture method ends up used just
# works without extra manual steps.
usermod -aG video "$RUN_USER"
if getent group render >/dev/null; then
  usermod -aG render "$RUN_USER"
fi
for f in /dev/dri/card*; do
  [ -e "$f" ] && chgrp video "$f" 2>/dev/null || true
done

# ==========================================================================
# Wi-Fi hotspot (SSID: RetroPie / password: retrogames)
#
# Forcibly rebuilt from scratch: any existing AP-mode connection or
# hostapd/dnsmasq config is torn down first, then a fresh hotspot is
# created. This only removes AP-mode Wi-Fi profiles - if this Pi also has
# a normal client Wi-Fi connection (e.g. for internet access), that
# profile is left alone.
# ==========================================================================

HOTSPOT_SSID="RetroPie"
HOTSPOT_PASSWORD="retrogames"

echo "==> Rebuilding the Wi-Fi hotspot from scratch (SSID: $HOTSPOT_SSID)..."
echo "    Any existing hotspot config on this Pi will be replaced."

WIFI_IFACE="$(iw dev 2>/dev/null | awk '/Interface/{print $2; exit}')"

if [ -z "$WIFI_IFACE" ]; then
  echo "    ERROR: no Wi-Fi interface found on this Pi - skipping hotspot setup."
  echo "    (The rest of the install will continue normally.)"
else
  echo "    Using Wi-Fi interface: $WIFI_IFACE"

  echo "    Tearing down any existing hotspot..."
  systemctl stop hostapd 2>/dev/null || true
  systemctl disable hostapd 2>/dev/null || true
  systemctl stop dnsmasq 2>/dev/null || true
  systemctl disable dnsmasq 2>/dev/null || true

  if command -v nmcli >/dev/null 2>&1; then
    # Only remove Wi-Fi connections that are in AP mode, so a normal client
    # Wi-Fi profile (e.g. this Pi's own internet connection) is untouched.
    while IFS= read -r NAME; do
      [ -z "$NAME" ] && continue
      MODE="$(nmcli -g 802-11-wireless.mode con show "$NAME" 2>/dev/null || true)"
      if [ "$MODE" = "ap" ]; then
        echo "    Removing existing AP connection: $NAME"
        nmcli con delete "$NAME" 2>/dev/null || true
      fi
    done < <(nmcli -t -f NAME,TYPE con show 2>/dev/null | awk -F: '$2=="wifi"{print $1}')
  fi

  # clean up old hostapd/dnsmasq/dhcpcd leftovers so nothing conflicts
  rm -f /etc/hostapd/hostapd.conf
  if [ -f /etc/dnsmasq.conf ]; then
    mv /etc/dnsmasq.conf "/etc/dnsmasq.conf.bak.$(date +%s)" 2>/dev/null || true
  fi
  if [ -f /etc/dhcpcd.conf ]; then
    sed -i "/^interface $WIFI_IFACE\$/,+2d" /etc/dhcpcd.conf || true
  fi
  rfkill unblock wifi 2>/dev/null || true

  echo "    Creating new hotspot..."
  if command -v nmcli >/dev/null 2>&1 && systemctl is-active --quiet NetworkManager 2>/dev/null; then
    echo "    Using NetworkManager (nmcli) on interface $WIFI_IFACE..."
    nmcli con add type wifi ifname "$WIFI_IFACE" con-name "$HOTSPOT_SSID" autoconnect yes ssid "$HOTSPOT_SSID"
    nmcli con modify "$HOTSPOT_SSID" 802-11-wireless.mode ap 802-11-wireless.band bg
    nmcli con modify "$HOTSPOT_SSID" ipv4.method shared
    nmcli con modify "$HOTSPOT_SSID" wifi-sec.key-mgmt wpa-psk
    nmcli con modify "$HOTSPOT_SSID" wifi-sec.psk "$HOTSPOT_PASSWORD"
    nmcli con up "$HOTSPOT_SSID"
  else
    echo "    NetworkManager not in use - using hostapd + dnsmasq on $WIFI_IFACE..."
    apt-get install -y hostapd dnsmasq
    systemctl unmask hostapd || true

    cat > /etc/hostapd/hostapd.conf <<EOF
interface=$WIFI_IFACE
driver=nl80211
ssid=$HOTSPOT_SSID
hw_mode=g
channel=7
wmm_enabled=0
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=$HOTSPOT_PASSWORD
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
EOF
    if grep -q '^#\?DAEMON_CONF=' /etc/default/hostapd 2>/dev/null; then
      sed -i 's|^#\?DAEMON_CONF=.*|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd
    else
      echo 'DAEMON_CONF="/etc/hostapd/hostapd.conf"' >> /etc/default/hostapd
    fi

    cat >> /etc/dhcpcd.conf <<EOF

interface $WIFI_IFACE
    static ip_address=192.168.50.1/24
    nohook wpa_supplicant
EOF

    cat > /etc/dnsmasq.conf <<EOF
interface=$WIFI_IFACE
dhcp-range=192.168.50.10,192.168.50.100,255.255.255.0,24h
EOF

    systemctl enable hostapd dnsmasq
    systemctl restart dhcpcd 2>/dev/null || true
    ip addr add 192.168.50.1/24 dev "$WIFI_IFACE" 2>/dev/null || true
    systemctl restart dnsmasq
    systemctl restart hostapd
  fi

  echo "    Hotspot '$HOTSPOT_SSID' is up on $WIFI_IFACE."
fi

echo "==> Stopping any previous RetroPie Web service before reinstalling..."
systemctl stop retropie-web 2>/dev/null || true

echo "==> Copying application to $INSTALL_DIR ..."
rm -rf "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR/server" "$SCRIPT_DIR/public" "$INSTALL_DIR"/
chown -R "$RUN_USER":"$RUN_USER" "$INSTALL_DIR"

echo "==> Installing Node dependencies..."
cd "$INSTALL_DIR/server"
sudo -u "$RUN_USER" npm install --omit=dev

echo "==> Allowing Node to bind to port 80 without running as root..."
setcap 'cap_net_bind_service=+ep' "$(readlink -f "$(command -v node)")"

echo "==> Granting ffmpeg permission for KMS/DRM screen capture..."
# kmsgrab reads DRM state directly (which plane is being scanned out, its
# buffer handle, etc.) and needs CAP_SYS_ADMIN even when the invoking user
# is in the video/render groups - this is a kmsgrab-specific requirement,
# not a general ffmpeg one.
FFMPEG_BIN="$(readlink -f "$(command -v ffmpeg)")"
if [ -n "$FFMPEG_BIN" ]; then
  setcap 'cap_sys_admin+ep' "$FFMPEG_BIN" || \
    echo "    WARNING: setcap failed - kmsgrab capture may not work without running as root."
fi

echo "==> Installing systemd service..."
sed "s#__INSTALL_DIR__#$INSTALL_DIR#g; s#__RUN_USER__#$RUN_USER#g" \
  "$SCRIPT_DIR/retropie-web.service" > /etc/systemd/system/retropie-web.service
systemctl daemon-reload
systemctl enable retropie-web
systemctl restart retropie-web

echo ""
echo "==> Done. RetroPie Web should now be running."
echo "    Connect to Wi-Fi '$HOTSPOT_SSID' (password: $HOTSPOT_PASSWORD) and visit: http://<pi-ip>/"
echo "    (find the IP with: hostname -I, or check 'systemctl status retropie-web')"
echo ""
echo "IMPORTANT: log out/reboot once so the '$RUN_USER' group membership"
echo "for uinput takes effect if the controller shows OFFLINE in the status bar."
