'use strict';

const { spawn } = require('child_process');

/**
 * Wraps ffmpeg to grab the Pi's display and re-encode it as an MJPEG stream
 * that any browser can display in an <img> tag. MJPEG is used instead of
 * WebRTC/HLS because it needs zero signaling/relay infrastructure -- it
 * works great on a plain local hotspot with near-zero setup, which matters
 * since there's no internet access to reach a STUN/TURN server.
 *
 * Three capture methods are supported:
 *  - kmsgrab (default): reads directly from the DRM plane actually being
 *    scanned out to the display. This is the correct method for RetroPie
 *    setups on a Pi 4, where EmulationStation/RetroArch render via KMS/DRM
 *    (GPU) and never touch X11 or the legacy fbdev console layer. Needs
 *    CAP_SYS_ADMIN on ffmpeg (granted by install.sh) and a correct
 *    `-device` (varies per Pi - card0 is often a render-only node that
 *    doesn't support the planes API; card1 is commonly the real display
 *    device) and pixel format (depends on what the compositor uses - see
 *    README's decode table; ARGB8888 -> "bgra", XRGB8888 -> "bgr0").
 *  - fbdev: legacy Linux framebuffer (/dev/fb0). Only correct if nothing
 *    is using KMS/DRM directly - usually just shows the text console on
 *    modern RetroPie setups, not the actual emulator output.
 *  - x11grab: only relevant if RetroPie runs under a full X11 desktop
 *    session rather than drawing straight to the display.
 */
class ScreenCapture {
  constructor(getConfig) {
    this.getConfig = getConfig; // () => config.capture
    this.proc = null;
    this.clients = new Set(); // res objects (express) currently streaming
    this.latestFrameBoundary = Buffer.from('--frame\r\n');
    this.restarting = false;
  }

  isRunning() {
    return !!this.proc;
  }

  buildArgs() {
    const cfg = this.getConfig();
    const scale = cfg.scale || '960x720';
    const outputArgs = [
      '-loglevel', 'error',
      '-f', 'mjpeg',
      '-q:v', String(cfg.quality || 6),
      '-r', String(cfg.fps || 20),
      'pipe:1'
    ];

    if (cfg.method === 'kmsgrab') {
      return [
        '-f', 'kmsgrab',
        '-device', cfg.kmsDevice || '/dev/dri/card1',
        '-framerate', String(cfg.fps || 20),
        '-i', '-',
        '-vf', `hwdownload,format=${cfg.kmsPixelFormat || 'bgra'},scale=${scale.replace('x', ':')},format=yuvj420p`,
        ...outputArgs
      ];
    }

    if (cfg.method === 'fbdev') {
      return [
        '-f', 'fbdev',
        '-framerate', String(cfg.fps || 20),
        '-i', cfg.framebufferDevice || '/dev/fb0',
        '-vf', `scale=${scale}`,
        ...outputArgs
      ];
    }

    // default: X11 screen grab
    return [
      '-f', 'x11grab',
      '-framerate', String(cfg.fps || 20),
      '-i', cfg.display || ':0',
      '-vf', `scale=${scale}`,
      ...outputArgs
    ];
  }

  start() {
    if (this.proc) return;
    const args = this.buildArgs();
    console.log('[capture] starting ffmpeg:', args.join(' '));

    this.proc = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] });

    let buffer = Buffer.alloc(0);
    const SOI = Buffer.from([0xff, 0xd8]); // JPEG start-of-image
    const EOI = Buffer.from([0xff, 0xd9]); // JPEG end-of-image

    this.proc.stdout.on('data', (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);

      // Extract complete JPEG frames from the raw mjpeg byte stream and
      // broadcast each one to every connected browser.
      let start = buffer.indexOf(SOI);
      while (start !== -1) {
        const end = buffer.indexOf(EOI, start + 2);
        if (end === -1) break;
        const frame = buffer.slice(start, end + 2);
        this.broadcast(frame);
        buffer = buffer.slice(end + 2);
        start = buffer.indexOf(SOI);
      }
      // keep buffer bounded in case of garbage / no signal
      if (buffer.length > 5 * 1024 * 1024) buffer = Buffer.alloc(0);
    });

    this.proc.stderr.on('data', (d) => {
      const msg = d.toString();
      if (msg.trim()) console.error('[ffmpeg]', msg.trim());
    });

    this.proc.on('exit', (code) => {
      console.log('[capture] ffmpeg exited with code', code);
      this.proc = null;
      if (!this.restarting && this.clients.size > 0) {
        // unexpected death while people are watching - try again shortly
        setTimeout(() => this.start(), 1500);
      }
    });
  }

  stop() {
    if (this.proc) {
      this.proc.kill('SIGTERM');
      this.proc = null;
    }
  }

  restart() {
    this.restarting = true;
    this.stop();
    setTimeout(() => {
      this.restarting = false;
      if (this.clients.size > 0) this.start();
    }, 400);
  }

  broadcast(frameBuffer) {
    const header = Buffer.from(
      `Content-Type: image/jpeg\r\nContent-Length: ${frameBuffer.length}\r\n\r\n`
    );
    for (const res of this.clients) {
      res.write(this.latestFrameBoundary);
      res.write(header);
      res.write(frameBuffer);
      res.write('\r\n');
    }
  }

  addClient(res) {
    this.clients.add(res);
    if (!this.proc) this.start();
  }

  removeClient(res) {
    this.clients.delete(res);
    if (this.clients.size === 0) this.stop();
  }
}

module.exports = ScreenCapture;
