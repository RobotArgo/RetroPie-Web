#!/usr/bin/env python3
"""
uinput_gamepad.py

Creates one or more virtual USB-style gamepads using Linux's uinput subsystem.
RetroArch / EmulationStation see these exactly like a real controller plugged
in over USB -- no special integration needed on the emulator side, just a
one-time "configure controller" pass per player slot. Button/axis identities
are stable across restarts AND across switching which on-screen console
layout you're using (NES, SNES, N64, etc.) - every layout in controller.js
just maps onto this same fixed set of physical buttons and axes, so
switching layouts never requires re-binding in RetroArch.

Listens on a Unix domain socket for newline-delimited JSON commands sent by
the Node server:
    {"player": 1, "type": "button", "name": "a", "state": "down"}
    {"player": 1, "type": "hat", "index": 0, "x": 1, "y": 0}
    {"player": 1, "type": "stick", "index": 0, "x": 0.5, "y": -0.3}
    {"player": 2, "type": "reset"}

Each virtual pad exposes:
  - 15 discrete buttons: a, b, c, x, y, z, l, r, l2, r2, start, select,
    mode, thumbl, thumbr
  - 2 hats (digital d-pad-style axes): hat 0 is the main d-pad, hat 1 is a
    secondary one (used for things like the N64's C-buttons)
  - 2 analog sticks: stick 0 (ABS_X/ABS_Y) and stick 1 (ABS_RX/ABS_RY)

Requires: python3-uinput (pip install python-uinput) and read/write access
to /dev/uinput (handled by the included udev rule + install script).
"""

import json
import os
import socket
import sys
import threading

try:
    import uinput
except ImportError:
    print("Missing dependency: pip install python-uinput (see README)", file=sys.stderr)
    sys.exit(1)

SOCKET_PATH = "/tmp/retropie-web-gamepad.sock"
MAX_PLAYERS = int(os.environ.get("RPWEB_PLAYERS", "2"))

EV_KEY = 0x01

# Raw (EV_KEY, code) tuples rather than named uinput.BTN_* constants, so
# this doesn't depend on exactly which names a given python-uinput version
# exposes. Codes match linux/input-event-codes.h's standard gamepad block.
BUTTON_CODES = {
    "a": 0x130, "b": 0x131, "c": 0x132, "x": 0x133, "y": 0x134, "z": 0x135,
    "l": 0x136, "r": 0x137, "l2": 0x138, "r2": 0x139,
    "select": 0x13a, "start": 0x13b, "mode": 0x13c,
    "thumbl": 0x13d, "thumbr": 0x13e,
}
BUTTON_MAP = {name: (EV_KEY, code) for name, code in BUTTON_CODES.items()}

# hat (d-pad-style) axes: hat 0 = main d-pad, hat 1 = secondary (N64 C-buttons etc.)
HAT_AXES = {
    0: (uinput.ABS_HAT0X + (-1, 1, 0, 0), uinput.ABS_HAT0Y + (-1, 1, 0, 0)),
    1: (uinput.ABS_HAT1X + (-1, 1, 0, 0), uinput.ABS_HAT1Y + (-1, 1, 0, 0)),
}

# analog sticks: stick 0 = left/main stick, stick 1 = right/secondary stick
STICK_RANGE = 127
STICK_AXES = {
    0: (uinput.ABS_X + (-STICK_RANGE, STICK_RANGE, 0, 0), uinput.ABS_Y + (-STICK_RANGE, STICK_RANGE, 0, 0)),
    1: (uinput.ABS_RX + (-STICK_RANGE, STICK_RANGE, 0, 0), uinput.ABS_RY + (-STICK_RANGE, STICK_RANGE, 0, 0)),
}

EVENTS = (
    list(BUTTON_MAP.values())
    + [axis for pair in HAT_AXES.values() for axis in pair]
    + [axis for pair in STICK_AXES.values() for axis in pair]
)


class VirtualPad:
    def __init__(self, index):
        self.index = index
        self.device = uinput.Device(EVENTS, name=f"RetroPieWeb Pad {index}")
        self.lock = threading.Lock()

    def button(self, name, state):
        code = BUTTON_MAP.get(name)
        if code is None:
            return
        with self.lock:
            self.device.emit(code, 1 if state == "down" else 0)

    def hat(self, index, x, y):
        axes = HAT_AXES.get(index)
        if axes is None:
            return
        x = max(-1, min(1, int(x)))
        y = max(-1, min(1, int(y)))
        with self.lock:
            self.device.emit(axes[0], x, syn=False)
            self.device.emit(axes[1], y)

    def stick(self, index, x, y):
        axes = STICK_AXES.get(index)
        if axes is None:
            return
        x = max(-1.0, min(1.0, float(x)))
        y = max(-1.0, min(1.0, float(y)))
        with self.lock:
            self.device.emit(axes[0], int(x * STICK_RANGE), syn=False)
            self.device.emit(axes[1], int(y * STICK_RANGE))

    def reset(self):
        with self.lock:
            for code in BUTTON_MAP.values():
                self.device.emit(code, 0)
            for axes in HAT_AXES.values():
                self.device.emit(axes[0], 0, syn=False)
                self.device.emit(axes[1], 0)
            for axes in STICK_AXES.values():
                self.device.emit(axes[0], 0, syn=False)
                self.device.emit(axes[1], 0)


def handle_client(conn, pads):
    buf = b""
    with conn:
        while True:
            try:
                chunk = conn.recv(4096)
            except OSError:
                break
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                if not line.strip():
                    continue
                try:
                    msg = json.loads(line.decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    continue
                dispatch(msg, pads)


def dispatch(msg, pads):
    player = int(msg.get("player", 1))
    pad = pads.get(player)
    if pad is None:
        return
    mtype = msg.get("type")
    if mtype == "button":
        pad.button(msg.get("name", ""), msg.get("state", "up"))
    elif mtype == "hat":
        pad.hat(msg.get("index", 0), msg.get("x", 0), msg.get("y", 0))
    elif mtype == "stick":
        pad.stick(msg.get("index", 0), msg.get("x", 0), msg.get("y", 0))
    elif mtype == "reset":
        pad.reset()


def main():
    pads = {i: VirtualPad(i) for i in range(1, MAX_PLAYERS + 1)}
    print(f"[uinput_gamepad] created {MAX_PLAYERS} virtual pad(s)")

    if os.path.exists(SOCKET_PATH):
        os.remove(SOCKET_PATH)

    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(SOCKET_PATH)
    os.chmod(SOCKET_PATH, 0o666)
    server.listen(4)
    print(f"[uinput_gamepad] listening on {SOCKET_PATH}")

    try:
        while True:
            conn, _ = server.accept()
            t = threading.Thread(target=handle_client, args=(conn, pads), daemon=True)
            t.start()
    except KeyboardInterrupt:
        pass
    finally:
        server.close()
        if os.path.exists(SOCKET_PATH):
            os.remove(SOCKET_PATH)


if __name__ == "__main__":
    main()
