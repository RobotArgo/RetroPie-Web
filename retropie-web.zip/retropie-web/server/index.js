'use strict';

const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const net = require('net');
const os = require('os');
const { spawn } = require('child_process');
const { WebSocketServer } = require('ws');
const ScreenCapture = require('./capture');

const CONFIG_PATH = path.join(__dirname, 'config.json');
const GAMEPAD_SOCKET = '/tmp/retropie-web-gamepad.sock';
const PORT = process.env.PORT || 80;

// ---------- config ----------
function loadConfig() {
  return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
}
function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}
let config = loadConfig();

// ---------- screen capture ----------
const capture = new ScreenCapture(() => config.capture);

// ---------- virtual gamepad daemon ----------
let gamepadProc = null;
let gamepadSocket = null;
let gamepadConnected = false;

function startGamepadDaemon() {
  if (gamepadProc) return;
  gamepadProc = spawn(
    'python3',
    [path.join(__dirname, 'uinput_gamepad.py')],
    {
      env: { ...process.env, RPWEB_PLAYERS: String(config.controller.players || 2) },
      stdio: ['ignore', 'pipe', 'pipe']
    }
  );
  gamepadProc.stdout.on('data', (d) => console.log('[gamepad]', d.toString().trim()));
  gamepadProc.stderr.on('data', (d) => console.error('[gamepad]', d.toString().trim()));
  gamepadProc.on('exit', (code) => {
    console.error('[gamepad] daemon exited', code, '- restarting in 2s');
    gamepadProc = null;
    gamepadConnected = false;
    setTimeout(startGamepadDaemon, 2000);
  });
  setTimeout(connectGamepadSocket, 800);
}

function connectGamepadSocket() {
  const sock = net.createConnection(GAMEPAD_SOCKET);
  sock.on('connect', () => {
    gamepadSocket = sock;
    gamepadConnected = true;
    console.log('[gamepad] connected to uinput daemon');
  });
  sock.on('error', () => {
    gamepadConnected = false;
    setTimeout(connectGamepadSocket, 1500);
  });
  sock.on('close', () => {
    gamepadConnected = false;
    setTimeout(connectGamepadSocket, 1500);
  });
}

function sendToGamepad(msg) {
  if (gamepadSocket && gamepadConnected) {
    gamepadSocket.write(JSON.stringify(msg) + '\n');
  }
}

startGamepadDaemon();

// ---------- express app ----------
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// MJPEG stream endpoint
app.get('/stream', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=frame',
    'Cache-Control': 'no-cache, private',
    Connection: 'close',
    Pragma: 'no-cache'
  });
  capture.addClient(res);
  req.on('close', () => capture.removeClient(res));
});

function localIp() {
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    for (const iface of ifaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) return iface.address;
    }
  }
  return '127.0.0.1';
}

app.get('/api/status', (req, res) => {
  res.json({
    ip: localIp(),
    screenActive: capture.isRunning(),
    screenViewers: capture.clients.size,
    controllerReady: gamepadConnected,
    players: config.controller.players,
    wsClients: wss.clients.size
  });
});

app.get('/api/config', (req, res) => res.json(config));

app.post('/api/config', (req, res) => {
  const incoming = req.body || {};
  config = {
    ...config,
    capture: { ...config.capture, ...(incoming.capture || {}) },
    controller: { ...config.controller, ...(incoming.controller || {}) },
    site: { ...config.site, ...(incoming.site || {}) }
  };
  saveConfig(config);

  // apply live where possible
  capture.restart();
  if (incoming.controller && incoming.controller.players) {
    if (gamepadProc) gamepadProc.kill('SIGTERM');
    gamepadConnected = false;
  }
  res.json({ ok: true, config });
});

const server = http.createServer(app);

// ---------- controller websocket ----------
const wss = new WebSocketServer({ server, path: '/controller-ws' });

wss.on('connection', (ws) => {
  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (!msg || !msg.type) return;
    sendToGamepad(msg);
  });
});

server.listen(PORT, () => {
  console.log(`RetroPie Web listening on port ${PORT}`);
  console.log(`Open http://${localIp()}${PORT === 80 ? '' : ':' + PORT} on a device connected to the RetroPie hotspot`);
});
