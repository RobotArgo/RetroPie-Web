'use strict';

/*
 * The stream is a plain multipart MJPEG response, so a browser <img> tag
 * can display it directly. We only set img.src while that view is actually
 * visible, and clear it (closing the HTTP connection) when the user leaves,
 * so ffmpeg on the Pi isn't burning CPU streaming to nobody.
 *
 * Placeholder visibility is driven entirely from JS (never from a CSS
 * selector keyed on the presence of img[src]) - a src attribute being set
 * doesn't mean a frame has actually arrived yet.
 */
const screenImg = document.getElementById('screen-img');
const bothScreenImg = document.getElementById('both-screen-img');
const screenPlaceholder = document.getElementById('screen-placeholder');
const bothPlaceholder = document.getElementById('both-screen-placeholder');

const STALL_TIMEOUT_MS = 6000;
const stallTimers = new WeakMap();

function attach(img, placeholder) {
  placeholder.style.display = 'flex';
  placeholder.textContent = 'Connecting…';

  img.onload = () => {
    clearTimeout(stallTimers.get(img));
    placeholder.style.display = 'none';
  };
  img.onerror = () => {
    clearTimeout(stallTimers.get(img));
    placeholder.style.display = 'flex';
    placeholder.textContent = 'No signal — check Settings › Screen Capture';
  };

  img.src = '/stream?ts=' + Date.now();

  // If the connection opens but no frame ever arrives (ffmpeg failing to
  // grab the display, wrong capture method, etc.), onload/onerror may
  // never fire at all. Fall back to an explicit message rather than a
  // silent black box.
  clearTimeout(stallTimers.get(img));
  const t = setTimeout(() => {
    placeholder.style.display = 'flex';
    placeholder.textContent = 'No signal after 6s — check Settings › Screen Capture';
  }, STALL_TIMEOUT_MS);
  stallTimers.set(img, t);
}

function detach(img, placeholder) {
  clearTimeout(stallTimers.get(img));
  img.removeAttribute('src');
  placeholder.style.display = 'flex';
  placeholder.textContent = 'Waiting for signal…';
}

window.addEventListener('rpweb:view', (e) => {
  const view = e.detail;
  if (view === 'screen') {
    attach(screenImg, screenPlaceholder);
  } else {
    detach(screenImg, screenPlaceholder);
  }

  if (view === 'both') {
    attach(bothScreenImg, bothPlaceholder);
  } else {
    detach(bothScreenImg, bothPlaceholder);
  }
});
