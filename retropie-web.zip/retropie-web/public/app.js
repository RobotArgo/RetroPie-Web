'use strict';

/* ---------- view routing ---------- */
const views = {
  home: document.getElementById('view-home'),
  screen: document.getElementById('view-screen'),
  controller: document.getElementById('view-controller'),
  both: document.getElementById('view-both'),
  settings: document.getElementById('view-settings')
};

function showView(name) {
  Object.entries(views).forEach(([key, el]) => {
    el.classList.toggle('hidden', key !== name);
  });
  window.dispatchEvent(new CustomEvent('rpweb:view', { detail: name }));
  if (history.state?.view !== name) {
    history.pushState({ view: name }, '', '#' + name);
  }
}

document.getElementById('menu-grid').addEventListener('click', (e) => {
  const card = e.target.closest('.menu-card');
  if (card) showView(card.dataset.target);
});

document.getElementById('open-settings').addEventListener('click', () => showView('settings'));

document.querySelectorAll('[data-back]').forEach((btn) => {
  btn.addEventListener('click', () => showView('home'));
});

window.addEventListener('popstate', (e) => {
  showView(e.state?.view || 'home');
});

// deep-link support (#controller etc.)
const initial = location.hash.replace('#', '');
if (views[initial]) showView(initial);

/* ---------- status bar polling ---------- */
async function pollStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    document.getElementById('stat-ip').textContent = data.ip;
    document.getElementById('stat-screen').textContent = data.screenActive ? `LIVE (${data.screenViewers})` : 'IDLE';
    document.getElementById('stat-pad').textContent = data.controllerReady ? 'READY' : 'OFFLINE';
    document.getElementById('dot-screen').className = 'dot ' + (data.screenActive ? 'on' : '');
    document.getElementById('dot-pad').className = 'dot ' + (data.controllerReady ? 'on' : 'off');
  } catch {
    document.getElementById('stat-ip').textContent = 'offline';
  }
}
pollStatus();
setInterval(pollStatus, 3000);

/* ---------- settings form ---------- */
const settingsForm = document.getElementById('settings-form');
const capMethod = document.getElementById('cap-method');
const fieldDisplay = document.getElementById('field-display');
const fieldFbdev = document.getElementById('field-fbdev');
const fieldKms = document.getElementById('field-kms');
const fieldKmsFmt = document.getElementById('field-kms-fmt');
const outFps = document.getElementById('out-fps');
const outQuality = document.getElementById('out-quality');

function toggleCaptureFields() {
  const method = capMethod.value;
  fieldKms.style.display = method === 'kmsgrab' ? 'flex' : 'none';
  fieldKmsFmt.style.display = method === 'kmsgrab' ? 'flex' : 'none';
  fieldFbdev.style.display = method === 'fbdev' ? 'flex' : 'none';
  fieldDisplay.style.display = method === 'x11grab' ? 'flex' : 'none';
}
capMethod.addEventListener('change', toggleCaptureFields);

function setFormValue(name, value) {
  const el = settingsForm.elements[name];
  if (!el) return;
  el.value = value;
  if (name === 'capture.fps') outFps.textContent = value + ' fps';
  if (name === 'capture.quality') outQuality.textContent = value;
}

async function loadSettingsIntoForm() {
  const res = await fetch('/api/config');
  const cfg = await res.json();
  setFormValue('capture.method', cfg.capture.method);
  setFormValue('capture.display', cfg.capture.display);
  setFormValue('capture.framebufferDevice', cfg.capture.framebufferDevice);
  setFormValue('capture.kmsDevice', cfg.capture.kmsDevice);
  setFormValue('capture.kmsPixelFormat', cfg.capture.kmsPixelFormat);
  setFormValue('capture.fps', cfg.capture.fps);
  setFormValue('capture.quality', cfg.capture.quality);
  setFormValue('capture.scale', cfg.capture.scale);
  setFormValue('controller.layout', cfg.controller.layout);
  setFormValue('controller.players', cfg.controller.players);
  setFormValue('site.name', cfg.site.name);
  toggleCaptureFields();
}
loadSettingsIntoForm();

settingsForm.elements['capture.fps'].addEventListener('input', (e) => {
  outFps.textContent = e.target.value + ' fps';
});
settingsForm.elements['capture.quality'].addEventListener('input', (e) => {
  outQuality.textContent = e.target.value;
});

settingsForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(settingsForm);
  const payload = { capture: {}, controller: {}, site: {} };
  for (const [key, value] of fd.entries()) {
    const [group, field] = key.split('.');
    if (!payload[group]) continue;
    payload[group][field] = value;
  }
  payload.capture.fps = Number(payload.capture.fps);
  payload.capture.quality = Number(payload.capture.quality);
  payload.controller.players = Number(payload.controller.players);

  const res = await fetch('/api/config', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const status = document.getElementById('save-status');
  if (res.ok) {
    status.textContent = 'Saved. Screen stream restarting…';
    status.classList.add('show');
    setTimeout(() => status.classList.remove('show'), 2500);
  } else {
    status.textContent = 'Failed to save.';
    status.classList.add('show');
  }
});
