'use strict';

/*
 * Each console layout is described declaratively - which physical elements
 * it has (d-pad, analog stick, shoulder/trigger buttons, a face-button
 * cluster, an optional secondary "hat" for things like the N64's C-buttons,
 * and the meta row) and what each control should be labeled. A small set of
 * shared renderers (diamond / pair / grid6 / stick / hat) turn that
 * description into markup, so adding another console is just adding a data
 * entry, not new layout code.
 *
 * Button `key`s sent over the wire match server/uinput_gamepad.py's
 * BUTTON_MAP exactly: a,b,c,x,y,z,l,r,l2,r2,start,select,mode,thumbl,thumbr.
 */
const LAYOUTS = {
  nes: {
    label: 'NES',
    dpad: true,
    face: { shape: 'pair', buttons: [{ key: 'b', label: 'B' }, { key: 'a', label: 'A' }] },
    meta: [{ key: 'select', label: 'SELECT' }, { key: 'start', label: 'START' }]
  },
  snes: {
    label: 'SNES',
    dpad: true,
    shoulders: [{ key: 'l', label: 'L' }, { key: 'r', label: 'R' }],
    face: {
      shape: 'diamond',
      buttons: {
        up: { key: 'x', label: 'X' },
        right: { key: 'a', label: 'A' },
        down: { key: 'b', label: 'B' },
        left: { key: 'y', label: 'Y' }
      }
    },
    meta: [{ key: 'select', label: 'SELECT' }, { key: 'start', label: 'START' }]
  },
  gb: {
    label: 'Game Boy',
    dpad: true,
    face: { shape: 'pair', buttons: [{ key: 'b', label: 'B' }, { key: 'a', label: 'A' }] },
    meta: [{ key: 'select', label: 'SELECT' }, { key: 'start', label: 'START' }]
  },
  gbc: {
    label: 'Game Boy Color',
    dpad: true,
    face: { shape: 'pair', buttons: [{ key: 'b', label: 'B' }, { key: 'a', label: 'A' }] },
    meta: [{ key: 'select', label: 'SELECT' }, { key: 'start', label: 'START' }]
  },
  gba: {
    label: 'Game Boy Advance',
    dpad: true,
    shoulders: [{ key: 'l', label: 'L' }, { key: 'r', label: 'R' }],
    face: { shape: 'pair', buttons: [{ key: 'b', label: 'B' }, { key: 'a', label: 'A' }] },
    meta: [{ key: 'select', label: 'SELECT' }, { key: 'start', label: 'START' }]
  },
  n64: {
    label: 'Nintendo 64',
    dpad: true,
    dpadLabel: 'D-PAD',
    stick: { index: 0, label: 'STICK' },
    shoulders: [{ key: 'l', label: 'L' }, { key: 'r', label: 'R' }, { key: 'z', label: 'Z' }],
    face: { shape: 'pair', buttons: [{ key: 'b', label: 'B' }, { key: 'a', label: 'A' }] },
    hat2: { index: 1, label: 'C', buttons: { up: 'C▲', right: 'C▶', down: 'C▼', left: 'C◀' } },
    meta: [{ key: 'start', label: 'START' }]
  },
  gamecube: {
    label: 'GameCube',
    dpad: true,
    stick: { index: 0, label: 'STICK' },
    shoulders: [{ key: 'l', label: 'L' }, { key: 'r', label: 'R' }, { key: 'z', label: 'Z' }],
    face: {
      shape: 'diamond',
      buttons: {
        up: { key: 'y', label: 'Y' },
        right: { key: 'a', label: 'A' },
        down: { key: 'b', label: 'B' },
        left: { key: 'x', label: 'X' }
      }
    },
    meta: [{ key: 'start', label: 'START' }]
  },
  wii: {
    label: 'Wii',
    dpad: true,
    shoulders: [
      { key: 'l', label: 'L' }, { key: 'r', label: 'R' },
      { key: 'l2', label: 'ZL' }, { key: 'r2', label: 'ZR' }
    ],
    face: {
      shape: 'diamond',
      buttons: {
        up: { key: 'x', label: 'X' },
        right: { key: 'a', label: 'A' },
        down: { key: 'b', label: 'B' },
        left: { key: 'y', label: 'Y' }
      }
    },
    meta: [
      { key: 'select', label: '−' },
      { key: 'start', label: '+' },
      { key: 'mode', label: 'HOME' }
    ]
  },
  ps4: {
    label: 'PlayStation 4',
    dpad: true,
    stick: { index: 0, label: 'L-STICK' },
    stick2: { index: 1, label: 'R-STICK' },
    shoulders: [
      { key: 'l', label: 'L1' }, { key: 'r', label: 'R1' },
      { key: 'l2', label: 'L2' }, { key: 'r2', label: 'R2' }
    ],
    face: {
      shape: 'diamond',
      buttons: {
        up: { key: 'y', label: '△' },
        right: { key: 'b', label: '○' },
        down: { key: 'a', label: '✕' },
        left: { key: 'x', label: '□' }
      }
    },
    meta: [{ key: 'select', label: 'SHARE' }, { key: 'start', label: 'OPTIONS' }]
  },
  megadrive: {
    label: 'Mega Drive / Genesis',
    dpad: true,
    face: {
      shape: 'grid6',
      buttons: [
        { key: 'x', label: 'X' }, { key: 'y', label: 'Y' }, { key: 'z', label: 'Z' },
        { key: 'a', label: 'A' }, { key: 'b', label: 'B' }, { key: 'c', label: 'C' }
      ]
    },
    meta: [{ key: 'mode', label: 'MODE' }, { key: 'start', label: 'START' }]
  },
  mame: {
    label: 'MAME / Arcade',
    dpad: true,
    face: {
      shape: 'grid6',
      buttons: [
        { key: 'x', label: '4' }, { key: 'y', label: '5' }, { key: 'z', label: '6' },
        { key: 'a', label: '1' }, { key: 'b', label: '2' }, { key: 'c', label: '3' }
      ]
    },
    meta: [{ key: 'select', label: 'COIN' }, { key: 'start', label: 'START' }]
  }
};

const STORAGE_KEY = 'rpweb-layout';
const POSITIONS_PREFIX = 'rpweb-positions:';

/* ---------- edit mode + saved positions ---------- */
let editMode = false;
let currentPositions = {}; // { dragId: {dx,dy} } for the active layout

function loadPositions(layoutKey) {
  try {
    const raw = localStorage.getItem(POSITIONS_PREFIX + layoutKey);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function savePositions() {
  try {
    localStorage.setItem(POSITIONS_PREFIX + activeLayout, JSON.stringify(currentPositions));
  } catch {
    /* storage unavailable - positions just won't persist, no crash */
  }
}

function applyOffset(element, dragId) {
  if (!dragId) return;
  const off = currentPositions[dragId];
  element.style.transform = off ? `translate(${off.dx}px, ${off.dy}px)` : '';
}

function setOffset(dragId, dx, dy) {
  currentPositions[dragId] = { dx: Math.round(dx), dy: Math.round(dy) };
  savePositions();
}

/* Makes `element` draggable when edit mode is on. Works whether `element`
   is a single button or a whole cluster (d-pad, stick, face cluster) -
   inner controls stay inert (see makeButton/buildHat/etc.) while edit mode
   is active, so a touch anywhere on a cluster bubbles up to this handler
   instead of sending game input. */
function makeDraggable(element, dragId) {
  applyOffset(element, dragId);
  let dragging = false;
  let pointerId = null;
  let startX = 0, startY = 0, baseDx = 0, baseDy = 0;

  element.addEventListener('pointerdown', (ev) => {
    if (!editMode) return;
    ev.preventDefault();
    ev.stopPropagation();
    dragging = true;
    pointerId = ev.pointerId;
    startX = ev.clientX;
    startY = ev.clientY;
    const off = currentPositions[dragId] || { dx: 0, dy: 0 };
    baseDx = off.dx;
    baseDy = off.dy;
    element.classList.add('dragging');
    try { element.setPointerCapture(pointerId); } catch { /* ignore */ }
  });
  element.addEventListener('pointermove', (ev) => {
    if (!dragging || ev.pointerId !== pointerId) return;
    ev.preventDefault();
    const dx = baseDx + (ev.clientX - startX);
    const dy = baseDy + (ev.clientY - startY);
    element.style.transform = `translate(${dx}px, ${dy}px)`;
  });
  const end = (ev) => {
    if (!dragging || ev.pointerId !== pointerId) return;
    dragging = false;
    element.classList.remove('dragging');
    setOffset(dragId, baseDx + (ev.clientX - startX), baseDy + (ev.clientY - startY));
  };
  element.addEventListener('pointerup', end);
  element.addEventListener('pointercancel', end);
}

function setEditMode(on) {
  editMode = on;
  document.querySelectorAll('.pad-layout').forEach((p) => p.classList.toggle('edit-mode', on));
  document.querySelectorAll('.edit-toggle-btn').forEach((b) => b.classList.toggle('active', on));
  document.querySelectorAll('.reset-layout-btn').forEach((b) => b.classList.toggle('hidden', !on));
  const hint = document.getElementById('edit-hint');
  if (hint) hint.classList.toggle('hidden', !on);
  if (on) send({ type: 'reset', player: activePlayer }); // release anything mid-press
}

function resetCurrentLayoutPositions() {
  currentPositions = {};
  try { localStorage.removeItem(POSITIONS_PREFIX + activeLayout); } catch { /* ignore */ }
  renderAllPads();
}

/* ---------- websocket ---------- */
let ws = null;
let wsReady = false;

function connectWs() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}/controller-ws`);
  ws.onopen = () => { wsReady = true; };
  ws.onclose = () => { wsReady = false; setTimeout(connectWs, 1000); };
  ws.onerror = () => ws.close();
}
connectWs();

function send(msg) {
  if (wsReady) ws.send(JSON.stringify(msg));
}

/* ---------- player selection ---------- */
let activePlayer = 1;
let totalPlayers = 2;

function renderPlayerSwitch(container) {
  container.innerHTML = '';
  for (let i = 1; i <= totalPlayers; i++) {
    const btn = document.createElement('button');
    btn.className = 'player-btn' + (i === activePlayer ? ' active' : '');
    btn.textContent = 'P' + i;
    btn.addEventListener('click', () => {
      activePlayer = i;
      document.querySelectorAll('.player-switch').forEach((sw) => {
        sw.querySelectorAll('.player-btn').forEach((b) => {
          b.classList.toggle('active', b.textContent === 'P' + i);
        });
      });
    });
    container.appendChild(btn);
  }
}

/* ---------- layout selection ---------- */
let activeLayout = localStorage.getItem(STORAGE_KEY) || 'snes';

function populateLayoutSelect(select) {
  select.innerHTML = '';
  Object.entries(LAYOUTS).forEach(([key, def]) => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = def.label;
    if (key === activeLayout) opt.selected = true;
    select.appendChild(opt);
  });
  select.addEventListener('change', () => {
    activeLayout = select.value;
    localStorage.setItem(STORAGE_KEY, activeLayout);
    document.querySelectorAll('.layout-select').forEach((s) => { s.value = activeLayout; });
    send({ type: 'reset', player: activePlayer });
    renderAllPads();
  });
}

/* ---------- rendering helpers ---------- */
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function makeButton(cls, label, onPress, onRelease, dragId) {
  const btn = el('button', 'pad-btn ' + cls, label);
  if (dragId) makeDraggable(btn, dragId);

  btn.addEventListener('pointerdown', (ev) => {
    if (editMode) return; // makeDraggable (if any) already handled this
    ev.preventDefault();
    btn.classList.add('pressed');
    onPress();
  });
  const release = (ev) => {
    if (editMode) return;
    ev.preventDefault();
    btn.classList.remove('pressed');
    onRelease();
  };
  btn.addEventListener('pointerup', release);
  btn.addEventListener('pointerleave', release);
  btn.addEventListener('pointercancel', release);
  return btn;
}

function buttonSend(key) {
  return {
    press: () => send({ type: 'button', player: activePlayer, name: key, state: 'down' }),
    release: () => send({ type: 'button', player: activePlayer, name: key, state: 'up' })
  };
}

/* d-pad -- sends hat index 0 */
function buildHat(hatIndex, labelText) {
  const state = { up: false, down: false, left: false, right: false };
  const sendHat = () => {
    const x = (state.right ? 1 : 0) - (state.left ? 1 : 0);
    const y = (state.down ? 1 : 0) - (state.up ? 1 : 0);
    send({ type: 'hat', index: hatIndex, player: activePlayer, x, y });
  };
  const wrap = el('div', 'dpad-wrap');
  const dirs = [
    ['up', 'dpad-up', '&#9650;'], ['down', 'dpad-down', '&#9660;'],
    ['left', 'dpad-left', '&#9664;'], ['right', 'dpad-right', '&#9654;']
  ];
  dirs.forEach(([dir, cls, glyph]) => {
    const btn = el('button', 'pad-btn dpad-btn ' + cls);
    btn.innerHTML = glyph;
    const press = (ev) => { if (editMode) return; ev.preventDefault(); btn.classList.add('pressed'); state[dir] = true; sendHat(); };
    const release = (ev) => { if (editMode) return; ev.preventDefault(); btn.classList.remove('pressed'); state[dir] = false; sendHat(); };
    btn.addEventListener('pointerdown', press);
    btn.addEventListener('pointerup', release);
    btn.addEventListener('pointerleave', release);
    btn.addEventListener('pointercancel', release);
    wrap.appendChild(btn);
  });
  wrap.appendChild(el('div', 'dpad-center'));
  const holder = el('div', 'control-holder');
  holder.appendChild(wrap);
  if (labelText) holder.appendChild(el('span', 'control-label', labelText));
  return holder;
}

/* small 4-direction cluster used for the N64's C-buttons -- visually
   smaller than the main d-pad, reuses the same hat-sending logic */
function buildMiniHat(hatIndex, labelText, glyphs) {
  const state = { up: false, down: false, left: false, right: false };
  const sendHat = () => {
    const x = (state.right ? 1 : 0) - (state.left ? 1 : 0);
    const y = (state.down ? 1 : 0) - (state.up ? 1 : 0);
    send({ type: 'hat', index: hatIndex, player: activePlayer, x, y });
  };
  const wrap = el('div', 'minihat-wrap');
  const dirs = [
    ['up', 'minihat-up', glyphs.up], ['down', 'minihat-down', glyphs.down],
    ['left', 'minihat-left', glyphs.left], ['right', 'minihat-right', glyphs.right]
  ];
  dirs.forEach(([dir, cls, label]) => {
    const btn = el('button', 'pad-btn minihat-btn ' + cls, label);
    const press = (ev) => { if (editMode) return; ev.preventDefault(); btn.classList.add('pressed'); state[dir] = true; sendHat(); };
    const release = (ev) => { if (editMode) return; ev.preventDefault(); btn.classList.remove('pressed'); state[dir] = false; sendHat(); };
    btn.addEventListener('pointerdown', press);
    btn.addEventListener('pointerup', release);
    btn.addEventListener('pointerleave', release);
    btn.addEventListener('pointercancel', release);
    wrap.appendChild(btn);
  });
  const holder = el('div', 'control-holder');
  holder.appendChild(wrap);
  holder.appendChild(el('span', 'control-label', labelText));
  return holder;
}

/* draggable analog stick -- reports normalized -1..1 x/y continuously */
function buildStick(index, labelText) {
  const base = el('div', 'stick-base');
  const knob = el('div', 'stick-knob');
  base.appendChild(knob);
  const holder = el('div', 'control-holder');
  holder.appendChild(base);
  holder.appendChild(el('span', 'control-label', labelText || 'STICK'));

  const RADIUS = 44; // px the knob can travel from center
  let dragging = false;
  let activeId = null;

  function setKnob(dx, dy) {
    knob.style.transform = `translate(${dx}px, ${dy}px)`;
  }

  function onMove(ev) {
    if (!dragging || ev.pointerId !== activeId) return;
    const rect = base.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = ev.clientX - cx;
    let dy = ev.clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > RADIUS) {
      dx = (dx / dist) * RADIUS;
      dy = (dy / dist) * RADIUS;
    }
    setKnob(dx, dy);
    send({ type: 'stick', index, player: activePlayer, x: +(dx / RADIUS).toFixed(2), y: +(dy / RADIUS).toFixed(2) });
  }

  function onUp(ev) {
    if (ev.pointerId !== activeId) return;
    dragging = false;
    activeId = null;
    setKnob(0, 0);
    send({ type: 'stick', index, player: activePlayer, x: 0, y: 0 });
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    window.removeEventListener('pointercancel', onUp);
  }

  base.addEventListener('pointerdown', (ev) => {
    if (editMode) return; // let it bubble to the holder's drag handler instead
    ev.preventDefault();
    dragging = true;
    activeId = ev.pointerId;
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
    onMove(ev);
  });

  return holder;
}

function buildFaceCluster(face) {
  if (face.shape === 'pair') {
    const wrap = el('div', 'face-wrap face-wrap-pair');
    const [first, second] = face.buttons;
    const { press: p1, release: r1 } = buttonSend(first.key);
    const { press: p2, release: r2 } = buttonSend(second.key);
    wrap.appendChild(makeButton('face-btn face-pair-left', first.label, p1, r1));
    wrap.appendChild(makeButton('face-btn face-pair-right', second.label, p2, r2));
    return wrap;
  }

  if (face.shape === 'grid6') {
    const wrap = el('div', 'face-grid6');
    face.buttons.forEach((b, i) => {
      const { press, release } = buttonSend(b.key);
      wrap.appendChild(makeButton('grid6-btn grid6-btn-' + i, b.label, press, release));
    });
    return wrap;
  }

  // diamond (default)
  const wrap = el('div', 'face-wrap');
  const positions = ['up', 'right', 'down', 'left'];
  positions.forEach((pos) => {
    const b = face.buttons[pos];
    const { press, release } = buttonSend(b.key);
    wrap.appendChild(makeButton('face-btn face-' + pos, b.label, press, release));
  });
  return wrap;
}

function buildLayout(layoutKey) {
  const def = LAYOUTS[layoutKey] || LAYOUTS.snes;
  const root = el('div', 'pad-built');

  // shoulders / triggers row(s)
  if (def.shoulders && def.shoulders.length) {
    const row = el('div', 'pad-shoulders');
    def.shoulders.forEach((s) => {
      const { press, release } = buttonSend(s.key);
      row.appendChild(makeButton('shoulder', s.label, press, release, 'shoulder-' + s.key));
    });
    root.appendChild(row);
  }

  // main area: left column (d-pad and/or stick), right column (face + hat2)
  const main = el('div', 'pad-main');
  const left = el('div', 'pad-col pad-col-left');
  const right = el('div', 'pad-col pad-col-right');

  if (def.stick) {
    const stickEl = buildStick(def.stick.index, def.stick.label);
    makeDraggable(stickEl, 'stick-' + def.stick.index);
    left.appendChild(stickEl);
  }
  if (def.dpad) {
    const dpadEl = buildHat(0, def.dpad && def.stick ? (def.dpadLabel || 'D-PAD') : null);
    makeDraggable(dpadEl, 'dpad');
    left.appendChild(dpadEl);
  }

  if (def.face) {
    const faceEl = buildFaceCluster(def.face);
    makeDraggable(faceEl, 'face');
    right.appendChild(faceEl);
  }
  if (def.hat2) {
    const hat2El = buildMiniHat(def.hat2.index, def.hat2.label, def.hat2.buttons);
    makeDraggable(hat2El, 'hat2');
    right.appendChild(hat2El);
  }
  if (def.stick2) {
    const stick2El = buildStick(def.stick2.index, def.stick2.label);
    makeDraggable(stick2El, 'stick-' + def.stick2.index);
    right.appendChild(stick2El);
  }

  main.appendChild(left);
  main.appendChild(right);
  root.appendChild(main);

  // meta row (select/start/mode/home)
  if (def.meta && def.meta.length) {
    const row = el('div', 'pad-center-row');
    def.meta.forEach((m) => {
      const { press, release } = buttonSend(m.key);
      row.appendChild(makeButton('meta-btn', m.label, press, release, 'meta-' + m.key));
    });
    root.appendChild(row);
  }

  return root;
}

function renderPad(container) {
  container.innerHTML = '';
  container.appendChild(buildLayout(activeLayout));
  container.classList.toggle('edit-mode', editMode);
}

function renderAllPads() {
  currentPositions = loadPositions(activeLayout);
  renderPad(document.getElementById('pad-layout'));
  renderPad(document.getElementById('both-pad-layout'));
}

/* ---------- init ---------- */
const layoutSelect = document.getElementById('layout-select');
const bothLayoutSelect = document.getElementById('both-layout-select');
populateLayoutSelect(layoutSelect);
populateLayoutSelect(bothLayoutSelect);
currentPositions = loadPositions(activeLayout);
renderAllPads();

function wireEditControls(toggleId, resetId) {
  const toggleBtn = document.getElementById(toggleId);
  const resetBtn = document.getElementById(resetId);
  if (!toggleBtn) return;
  toggleBtn.addEventListener('click', () => setEditMode(!editMode));
  resetBtn.addEventListener('click', () => resetCurrentLayoutPositions());
}
wireEditControls('edit-toggle', 'reset-layout');
wireEditControls('both-edit-toggle', 'both-reset-layout');

fetch('/api/config').then((r) => r.json()).then((cfg) => {
  totalPlayers = cfg.controller.players || 2;
  renderPlayerSwitch(document.getElementById('player-switch'));
  renderPlayerSwitch(document.getElementById('both-player-switch'));

  // Only fall back to the server's configured default layout if the
  // browser has never picked one before.
  if (!localStorage.getItem(STORAGE_KEY) && cfg.controller.layout && LAYOUTS[cfg.controller.layout]) {
    activeLayout = cfg.controller.layout;
    layoutSelect.value = activeLayout;
    bothLayoutSelect.value = activeLayout;
    renderAllPads();
  }
});

// Release everything if the tab loses visibility mid-press (e.g. app switch)
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    send({ type: 'reset', player: activePlayer });
    document.querySelectorAll('.pad-btn.pressed').forEach((b) => b.classList.remove('pressed'));
  }
});
